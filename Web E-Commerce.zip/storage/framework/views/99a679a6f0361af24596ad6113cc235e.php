<?php $__env->startSection('content'); ?>

    <div class="untree_co-section product-section before-footer-section">
        <div class="container">
            <div class="row">

                <!-- Start Column 1 -->
                <?php $__currentLoopData = $produck; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-12 col-md-4 col-lg-3 mb-5">
                        <a class="product-item" 
                            <?php if(auth()->guard()->check()): ?>
                                onclick="detailProduk(this)" data-id="<?php echo e($data->uuid); ?>"
                            <?php else: ?>
                                href="<?php echo e(route('login')); ?>"
                            <?php endif; ?>
                        >
                            <img src="<?php echo e(asset($data->image)); ?>" class="img-fluid product-thumbnail">
                            <h3 class="product-title"><?php echo e($data->jasa_produk); ?></h3>
                            <strong class="product-price">Rp.<?php echo e(number_format($data->harga, 0, ',', '.')); ?></strong>

                            <span class="icon-cross">
                                <img src="<?php echo e(asset('frontend')); ?>/images/cross.svg" class="img-fluid">
                            </span>
                        </a>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- End Column 1 -->
            </div>
        </div>
    </div>

    <?php echo $__env->make('frontend.detail_produk', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php $__env->startPush('js'); ?>
    <!-- Load jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Load SweetAlert -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Load custom scripts -->
    <script src="<?php echo e(asset('frontend/js/shop.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/asset/backend/js/helper.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.template.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Toko-\resources\views/frontend/shop.blade.php ENDPATH**/ ?>