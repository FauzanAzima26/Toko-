<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">

  <ul class="sidebar-nav" id="sidebar-nav">

    <li class="nav-item">
      <a class="nav-link <?php echo e(request()->routeIs('admin.inventaris.index') ? 'active' : 'collapsed'); ?>"
        href="<?php echo e(route('admin.inventaris.index')); ?>">
        <i class="bi bi-grid"></i>
        <span>Inventaris</span>
      </a>
    </li><!-- End Dashboard Nav -->

    <li class="nav-item">
      <a class="nav-link <?php echo e(request()->routeIs('log') ? 'active' : 'collapsed'); ?>" href="<?php echo e(route('log')); ?>">
        <i class="bi bi-grid"></i>
        <span>Log Harian</span>
      </a>
    </li><!-- End Log Harian Nav -->

    <li class="nav-item">
      <a class="nav-link <?php echo e(request()->routeIs('admin.jasa_produk.index') ? 'active' : 'collapsed'); ?>" href="<?php echo e(route('admin.jasa_produk.index')); ?>">
        <i class="bi bi-grid"></i>
        <span>Jasa/Produk</span>
      </a>
    </li><!-- End Jasa/Produk Nav -->

    <li class="nav-heading">Pages</li>

    <li class="nav-item">
      <a class="nav-link collapsed" href="<?php echo e(route('logout')); ?>" onclick=" event.preventDefault();
                            document.getElementById('logout-form').submit();"">
        <i class=" bi bi-box-arrow-in-right"></i>
        <span>Logout</span>
      </a>
      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
        <?php echo csrf_field(); ?>
      </form>
    </li><!-- End Logout Nav -->

  </ul>

</aside><!-- End Sidebar --><?php /**PATH C:\laragon\www\Toko-\resources\views/backend/template/sidebar.blade.php ENDPATH**/ ?>